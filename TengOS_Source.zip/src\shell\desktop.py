import sys
import subprocess
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QApplication
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QPixmap, QIcon

class DesktopIcon(QWidget):
    def __init__(self, name, command, parent=None):
        super().__init__(parent)
        self.command = command
        
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Simple placeholder for icon since we don't load external svgs here for prototype
        self.icon_lbl = QLabel()
        self.icon_lbl.setFixedSize(64, 64)
        self.icon_lbl.setStyleSheet("background-color: rgba(255, 255, 255, 0.1); border-radius: 16px;")
        
        # If it's chrome, give it a slight blue tint, if files, a gray tint for distinction in prototype
        if "chrome" in name.lower() or "chromium" in name.lower():
            self.icon_lbl.setStyleSheet("background-color: rgba(220, 230, 242, 0.2); border-radius: 16px; border: 1px solid rgba(255,255,255,0.2);")
        
        self.text_lbl = QLabel(name)
        self.text_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.text_lbl.setStyleSheet("color: white; font-family: 'Inter', sans-serif; font-size: 12px;")
        
        layout.addWidget(self.icon_lbl, alignment=Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.text_lbl, alignment=Qt.AlignmentFlag.AlignCenter)
        
        self.setLayout(layout)
        self.setFixedSize(100, 100)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            subprocess.Popen(self.command, shell=True)

class DesktopEnvironment(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        
    def initUI(self):
        # Frameless, transparent, stays on bottom
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnBottomHint | Qt.WindowType.Tool)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        
        # Assuming 1920x1080 for prototype
        self.setGeometry(0, 0, 1920, 1080)
        
        # Layout for icons (Top-Left to Bottom)
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(20, 60, 20, 20) # 60 top margin to avoid panel
        main_layout.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        
        # Add Desktop Icons
        icon_files = DesktopIcon("Files", "thunar")
        icon_chrome = DesktopIcon("Google Chrome", "chromium")
        icon_recovery = DesktopIcon("System Recovery", "python /opt/tengos-shell/recovery.py")
        
        main_layout.addWidget(icon_files)
        main_layout.addWidget(icon_chrome)
        main_layout.addWidget(icon_recovery)
        
        self.setLayout(main_layout)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = DesktopEnvironment()
    window.show()
    sys.exit(app.exec())
