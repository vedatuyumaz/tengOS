import sys
from PySide6.QtCore import QObject, Slot
try:
    from PySide6.QtDBus import QDBusConnection
except ImportError:
    QDBusConnection = None
    print("Warning: QtDBus module not found. DBus integration will be disabled.")

from launcher import AppLauncher

class ShellDBusService(QObject):
    def __init__(self, panel, control_center=None):
        super().__init__()
        self.panel = panel
        self.control_center = control_center
        
        # Initialize the launcher window but keep it hidden
        self.launcher = AppLauncher()
        self.launcher.hide()
        
        # Connect panel button to launcher toggle
        self.panel.btn_launcher.clicked.connect(self.launcher.toggle_visibility)

        # Register DBus service if available
        if QDBusConnection is not None:
            self.session_bus = QDBusConnection.sessionBus()
            self.session_bus.registerService('org.tengos.Shell')
            self.session_bus.registerObject('/org/tengos/Shell', self, QDBusConnection.ExportAllSlots)

    @Slot()
    def ToggleLauncher(self):
        self.launcher.toggle_visibility()

    @Slot()
    def ToggleControlCenter(self):
        if self.control_center:
            self.control_center.toggle_visibility()
