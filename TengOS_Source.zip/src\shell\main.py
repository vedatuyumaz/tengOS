#!/usr/bin/env python3
import sys
import os
from PySide6.QtWidgets import QApplication
from panel import TopPanel
from dbus_service import ShellDBusService
from control_center import ControlCenter

def main():
    # Set Wayland specific environment variables to ensure Qt uses Wayland native backend
    os.environ["QT_QPA_PLATFORM"] = "wayland"
    
    app = QApplication(sys.argv)
    app.setApplicationName("tengos-shell")
    
    # Initialize the top panel (Taskbar)
    panel = TopPanel()
    panel.show()
    
    # Initialize Control Center (hidden by default)
    control_center = ControlCenter()
    control_center.hide()

    # Connect panel indicators to Control Center toggle
    panel.btn_network.clicked.connect(control_center.toggle_visibility)
    panel.btn_battery.clicked.connect(control_center.toggle_visibility)
    
    # Initialize DBus service to listen for shortcuts
    dbus_service = ShellDBusService(panel, control_center)
    
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
