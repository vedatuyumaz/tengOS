#!/usr/bin/env bash

# Teng OS Build Script
# This script must be run on an Arch Linux system (or VM/WSL) with 'archiso' installed.
# Usage: sudo ./build.sh

set -e

if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root (sudo)." 
   exit 1
fi

if ! command -v mkarchiso &> /dev/null; then
    echo "archiso package is not installed. Please run: pacman -S archiso"
    exit 1
fi

echo "==> Preparing Teng OS build environment..."

WORK_DIR="/tmp/tengos-build"
OUT_DIR="./out"
PROFILE_DIR="./archiso-profile"

# Clean previous build
rm -rf "$WORK_DIR"
mkdir -p "$WORK_DIR"
mkdir -p "$OUT_DIR"

# Copy the default releng profile as a base
cp -r /usr/share/archiso/configs/releng/* "$WORK_DIR/"

# Overlay our custom configurations
echo "==> Applying custom configurations..."
cp -v "$PROFILE_DIR/profiledef.sh" "$WORK_DIR/"
cp -v "$PROFILE_DIR/packages.x86_64" "$WORK_DIR/"
cp -v "$PROFILE_DIR/pacman.conf" "$WORK_DIR/"
cp -rv "$PROFILE_DIR/airootfs/"* "$WORK_DIR/airootfs/" 2>/dev/null || true

# Install custom Python shell into /opt
mkdir -p "$WORK_DIR/airootfs/opt/tengos-shell"
cp -rv ./src/shell/* "$WORK_DIR/airootfs/opt/tengos-shell/"

# Set proper permissions for the overlay
chmod -R 755 "$WORK_DIR/airootfs/etc/systemd/system-preset"

echo "==> Starting mkarchiso..."
mkarchiso -v -w "$WORK_DIR/work" -o "$OUT_DIR" "$WORK_DIR/"

echo "==> Build complete! ISO is located in $OUT_DIR"
