import sys
import subprocess
import os
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLineEdit, QListWidget, QLabel
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QIcon, QFont, QColor

class AppLauncher(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        
    def initUI(self):
        # Frameless, stays on top, tool window so it doesn't show in taskbar itself
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.Tool)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        
        # Geometry: Centered on screen or docked to bottom. Let's make it an overlay centered.
        # Assuming 1920x1080 for this prototype.
        width = 600
        height = 500
        x = (1920 - width) // 2
        y = (1080 - height) // 2
        self.setGeometry(x, y, width, height)
        self.setObjectName("tengos-shell-launcher")

        # Styling
        self.setStyleSheet("""
            QWidget#tengos-shell-launcher {
                background-color: rgba(30, 30, 30, 0.90);
                border-radius: 16px;
                border: 1px solid rgba(255, 255, 255, 0.15);
            }
            QLineEdit {
                background-color: rgba(0, 0, 0, 0.3);
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 8px;
                padding: 12px;
                color: #ffffff;
                font-family: 'Inter', sans-serif;
                font-size: 16px;
            }
            QLineEdit:focus {
                border: 1px solid rgba(220, 230, 242, 0.8);
            }
            QListWidget {
                background: transparent;
                border: none;
                color: #ffffff;
                font-family: 'Inter', sans-serif;
                font-size: 14px;
            }
            QListWidget::item {
                padding: 10px;
                border-radius: 8px;
            }
            QListWidget::item:selected {
                background-color: rgba(220, 230, 242, 0.15);
            }
        """)

        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        # Title / Search Bar
        self.search_bar = QLineEdit()
        self.search_bar.setPlaceholderText("Search apps, files, or settings...")
        layout.addWidget(self.search_bar)

        # App List (Mockup data but real actions for App Store)
        self.app_list = QListWidget()
        self.app_list.setIconSize(QSize(32, 32))
        
        self.apps = {
            "Web Browser": "xdg-open https://google.com",
            "Terminal": "kitty",
            "App Store": "python /opt/tengos-shell/app_store.py"
        }
        
        for app in self.apps.keys():
            self.app_list.addItem(app)
            
        self.app_list.itemClicked.connect(self.launch_app)
        layout.addWidget(self.app_list)
        self.setLayout(layout)

    def launch_app(self, item):
        app_name = item.text()
        command = self.apps.get(app_name)
        if command:
            subprocess.Popen(command, shell=True)
            self.hide()

    def toggle_visibility(self):
        if self.isVisible():
            self.hide()
        else:
            self.show()
            self.search_bar.setFocus()
