import sys
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, 
                               QListWidget, QListWidgetItem, QLabel, QPushButton, 
                               QApplication, QMessageBox)
from PySide6.QtCore import Qt, QProcess

class RecoveryTool(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.process = QProcess(self)
        self.process.readyReadStandardOutput.connect(self.handle_stdout)
        self.process.finished.connect(self.process_finished)
        self.current_action = None
        self.load_snapshots()

    def initUI(self):
        self.setWindowTitle("Teng OS Recovery")
        self.resize(700, 500)
        self.setObjectName("tengos-recovery")

        self.setStyleSheet("""
            QWidget#tengos-recovery {
                background-color: #1a1a1a;
            }
            QLabel {
                color: #ffffff;
                font-family: 'Inter', sans-serif;
            }
            QListWidget {
                background-color: transparent;
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 8px;
                outline: none;
                padding: 5px;
            }
            QListWidget::item {
                background-color: #222222;
                border-radius: 6px;
                margin-bottom: 5px;
                padding: 12px;
                color: #ffffff;
            }
            QListWidget::item:selected {
                background-color: rgba(220, 230, 242, 0.15);
                border: 1px solid rgba(220, 230, 242, 0.4);
            }
            QPushButton {
                background-color: #333333;
                color: #ffffff;
                border: none;
                border-radius: 6px;
                padding: 10px 20px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #444444;
            }
            QPushButton.restore-btn {
                background-color: #ffffff;
                color: #000000;
            }
            QPushButton.restore-btn:hover {
                background-color: #e0e0e0;
            }
        """)

        layout = QVBoxLayout()
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(15)

        title = QLabel("System Recovery")
        title.setStyleSheet("font-size: 24px; font-weight: bold; letter-spacing: 1px;")
        layout.addWidget(title)

        desc = QLabel("Select a snapshot to restore your system to a previous working state.")
        desc.setStyleSheet("color: rgba(255, 255, 255, 0.6);")
        layout.addWidget(desc)

        self.snapshot_list = QListWidget()
        layout.addWidget(self.snapshot_list)

        action_layout = QHBoxLayout()
        self.btn_refresh = QPushButton("Refresh")
        self.btn_refresh.clicked.connect(self.load_snapshots)
        
        self.btn_restore = QPushButton("Restore System")
        self.btn_restore.setProperty("class", "restore-btn")
        self.btn_restore.clicked.connect(self.restore_selected)

        action_layout.addWidget(self.btn_refresh)
        action_layout.addStretch()
        action_layout.addWidget(self.btn_restore)
        
        layout.addLayout(action_layout)
        self.setLayout(layout)
        self.output_buffer = ""

    def load_snapshots(self):
        self.snapshot_list.clear()
        self.current_action = "list"
        self.output_buffer = ""
        # Requires pkexec since snapper needs root for system configs
        self.process.start("pkexec", ["snapper", "--csvout", "list"])

    def restore_selected(self):
        item = self.snapshot_list.currentItem()
        if not item:
            return
            
        snap_id = item.data(Qt.ItemDataRole.UserRole)
        reply = QMessageBox.warning(self, 'Confirm System Restore', 
                                     f"Are you absolutely sure you want to restore to snapshot #{snap_id}?\nYour system will be rolled back and rebooted. This requires authentication.",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        
        if reply == QMessageBox.StandardButton.Yes:
            self.current_action = "restore"
            self.process.start("pkexec", ["snapper", "undochange", f"{snap_id}..0"])

    def handle_stdout(self):
        data = self.process.readAllStandardOutput().data().decode('utf-8', errors='ignore')
        self.output_buffer += data

    def process_finished(self, exitCode, exitStatus):
        if self.current_action == "list":
            if exitCode == 0 and self.output_buffer:
                self.parse_snapper_list(self.output_buffer)
            else:
                self.snapshot_list.addItem("Failed to load snapshots. Is snapper configured?")
        elif self.current_action == "restore":
            if exitCode == 0:
                QMessageBox.information(self, "Success", "System restored successfully. Please reboot.")
            else:
                QMessageBox.warning(self, "Error", "System restore failed. Check permissions and btrfs layout.")
                
        self.current_action = None

    def parse_snapper_list(self, raw_data):
        lines = raw_data.strip().split('\n')
        # CSV format: #,Type,Pre #,Date,User,Cleanup,Description,Userdata
        # Skip header
        if len(lines) > 1:
            for line in lines[1:]:
                parts = line.split(',')
                if len(parts) >= 7:
                    snap_id = parts[0]
                    date = parts[3]
                    desc = parts[6]
                    if not desc:
                        desc = "System state"
                    
                    display_text = f"Snapshot #{snap_id} - {date}\n{desc}"
                    item = QListWidgetItem(display_text)
                    item.setData(Qt.ItemDataRole.UserRole, snap_id)
                    self.snapshot_list.addItem(item)
        else:
            self.snapshot_list.addItem("No snapshots available.")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = RecoveryTool()
    window.show()
    sys.exit(app.exec())
