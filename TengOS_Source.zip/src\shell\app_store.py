import sys
import re
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, 
                               QListWidget, QListWidgetItem, QLabel, QPushButton, 
                               QApplication, QProgressBar, QMessageBox, QComboBox)
from PySide6.QtCore import Qt, QProcess, QSize
from PySide6.QtGui import QFont

class AppStore(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.process = QProcess(self)
        self.process.readyReadStandardOutput.connect(self.handle_stdout)
        self.process.finished.connect(self.process_finished)
        self.current_action = None

    def initUI(self):
        self.setWindowTitle("Teng OS App Store")
        self.resize(900, 600)
        self.setObjectName("tengos-appstore")

        # Classy, grayscale & whitish-blue theme
        self.setStyleSheet("""
            QWidget#tengos-appstore {
                background-color: #1a1a1a;
            }
            QLabel {
                color: #ffffff;
                font-family: 'Inter', sans-serif;
            }
            QLineEdit {
                background-color: #2a2a2a;
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 6px;
                padding: 10px;
                color: #ffffff;
                font-size: 14px;
            }
            QLineEdit:focus {
                border: 1px solid rgba(220, 230, 242, 0.8);
            }
            QListWidget {
                background-color: transparent;
                border: none;
                outline: none;
            }
            QListWidget::item {
                background-color: #222222;
                border-radius: 8px;
                margin-bottom: 8px;
                padding: 10px;
                color: #ffffff;
            }
            QListWidget::item:selected {
                background-color: rgba(220, 230, 242, 0.15);
                border: 1px solid rgba(220, 230, 242, 0.4);
            }
            QPushButton {
                background-color: #333333;
                color: #ffffff;
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #444444;
            }
            QPushButton.install-btn {
                background-color: #ffffff;
                color: #000000;
            }
            QPushButton.install-btn:hover {
                background-color: #e0e0e0;
            }
            QPushButton.remove-btn {
                background-color: #552222;
                color: #ffffff;
            }
            QPushButton.remove-btn:hover {
                background-color: #773333;
            }
            QProgressBar {
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 4px;
                text-align: center;
                background-color: #222222;
                color: white;
            }
            QProgressBar::chunk {
                background-color: rgba(220, 230, 242, 0.8);
            }
        """)

        layout = QVBoxLayout()
        layout.setContentsMargins(30, 30, 30, 30)

        # Header & Search
        header_layout = QHBoxLayout()
        title = QLabel("App Store")
        title.setStyleSheet("font-size: 24px; font-weight: bold; letter-spacing: 1px;")
        header_layout.addWidget(title)
        
        header_layout.addStretch()

        self.backend_combo = QComboBox()
        self.backend_combo.addItems(["Pacman (System)", "Flatpak (Sandbox)"])
        self.backend_combo.setStyleSheet("""
            QComboBox {
                background-color: #2a2a2a;
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 6px;
                color: white;
                padding: 8px;
            }
        """)
        header_layout.addWidget(self.backend_combo)

        self.search_bar = QLineEdit()
        self.search_bar.setPlaceholderText("Search apps...")
        self.search_bar.setFixedWidth(300)
        self.search_bar.returnPressed.connect(self.search_apps)
        header_layout.addWidget(self.search_bar)
        
        self.btn_search = QPushButton("Search")
        self.btn_search.clicked.connect(self.search_apps)
        header_layout.addWidget(self.btn_search)

        layout.addLayout(header_layout)

        # Progress Bar (hidden by default)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 0) # Indeterminate
        self.progress_bar.hide()
        layout.addWidget(self.progress_bar)

        # Status Label
        self.lbl_status = QLabel("")
        self.lbl_status.setStyleSheet("color: rgba(255, 255, 255, 0.5); font-size: 12px;")
        layout.addWidget(self.lbl_status)

        # Results List
        self.result_list = QListWidget()
        layout.addWidget(self.result_list)

        # Action Buttons (Install/Remove)
        action_layout = QHBoxLayout()
        self.btn_install = QPushButton("Install Selected")
        self.btn_install.setProperty("class", "install-btn")
        self.btn_install.clicked.connect(self.install_selected)
        
        self.btn_remove = QPushButton("Remove Selected")
        self.btn_remove.setProperty("class", "remove-btn")
        self.btn_remove.clicked.connect(self.remove_selected)

        action_layout.addWidget(self.btn_remove)
        action_layout.addStretch()
        action_layout.addWidget(self.btn_install)
        
        layout.addLayout(action_layout)

        self.setLayout(layout)
        self.search_buffer = ""

    def search_apps(self):
        query = self.search_bar.text().strip()
        if not query:
            return
            
        self.result_list.clear()
        self.search_buffer = ""
        backend = self.backend_combo.currentText()
        self.lbl_status.setText(f"Searching {backend} for '{query}'...")
        self.progress_bar.show()
        
        # Real Search Execution
        self.current_action = "search"
        if "Pacman" in backend:
            self.process.start("pacman", ["-Ss", query])
        else:
            self.process.start("flatpak", ["search", query])

    def install_selected(self):
        item = self.result_list.currentItem()
        if not item:
            return
            
        pkg_name = item.data(Qt.ItemDataRole.UserRole)
        backend = self.backend_combo.currentText()
        
        reply = QMessageBox.question(self, 'Confirm Installation', 
                                     f"Are you sure you want to install {pkg_name}?\nThis may require authentication.",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        
        if reply == QMessageBox.StandardButton.Yes:
            self.lbl_status.setText(f"Installing {pkg_name}...")
            self.progress_bar.show()
            self.current_action = "install"
            if "Pacman" in backend:
                self.process.start("pkexec", ["pacman", "-S", "--noconfirm", pkg_name])
            else:
                self.process.start("flatpak", ["install", "-y", pkg_name])

    def remove_selected(self):
        item = self.result_list.currentItem()
        if not item:
            return
            
        pkg_name = item.data(Qt.ItemDataRole.UserRole)
        backend = self.backend_combo.currentText()
        
        reply = QMessageBox.question(self, 'Confirm Removal', 
                                     f"Are you sure you want to completely remove {pkg_name}?\nThis may require authentication.",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        
        if reply == QMessageBox.StandardButton.Yes:
            self.lbl_status.setText(f"Removing {pkg_name}...")
            self.progress_bar.show()
            self.current_action = "remove"
            if "Pacman" in backend:
                self.process.start("pkexec", ["pacman", "-Rns", "--noconfirm", pkg_name])
            else:
                self.process.start("flatpak", ["uninstall", "-y", pkg_name])

    def handle_stdout(self):
        data = self.process.readAllStandardOutput().data().decode('utf-8', errors='ignore')
        
        if self.current_action == "search":
            self.search_buffer += data
        else:
            # For install/remove, just show the last line in status
            lines = data.strip().split('\n')
            if lines and lines[-1]:
                self.lbl_status.setText(lines[-1][:80] + "...")

    def process_finished(self, exitCode, exitStatus):
        self.progress_bar.hide()
        
        if self.current_action == "search":
            self.lbl_status.setText("Search completed.")
            if "Pacman" in self.backend_combo.currentText():
                self.parse_pacman_search(self.search_buffer)
            else:
                self.parse_flatpak_search(self.search_buffer)
        elif self.current_action == "install":
            if exitCode == 0:
                self.lbl_status.setText("Installation completed successfully!")
                QMessageBox.information(self, "Success", "Package installed successfully.")
            else:
                self.lbl_status.setText("Installation failed or was cancelled.")
                QMessageBox.warning(self, "Error", "Package installation failed. Check your permissions.")
        elif self.current_action == "remove":
            if exitCode == 0:
                self.lbl_status.setText("Removal completed successfully!")
                QMessageBox.information(self, "Success", "Package removed successfully.")
            else:
                self.lbl_status.setText("Removal failed or was cancelled.")
                
        self.current_action = None

    def parse_pacman_search(self, raw_data):
        # pacman -Ss output format:
        # repo/pkgname version [installed]
        #     Description
        lines = raw_data.split('\n')
        current_pkg = None
        
        for line in lines:
            if not line.startswith(' ') and '/' in line:
                parts = line.split(' ')
                repo_pkg = parts[0]
                version = parts[1] if len(parts) > 1 else ""
                installed = "[installed]" in line
                
                repo, pkg_name = repo_pkg.split('/', 1)
                current_pkg = {"name": pkg_name, "repo": repo, "version": version, "installed": installed, "desc": ""}
            elif line.startswith('    ') and current_pkg:
                current_pkg["desc"] = line.strip()
                self.add_item_to_list(current_pkg)
                current_pkg = None

    def parse_flatpak_search(self, raw_data):
        lines = raw_data.split('\n')
        for line in lines:
            parts = line.split('\t')
            if len(parts) >= 4:
                # Flatpak search format: Name \t Description \t Application ID \t Version \t Branch \t Remotes
                name = parts[0].strip()
                desc = parts[1].strip()
                app_id = parts[2].strip()
                version = parts[3].strip() if len(parts) > 3 else ""
                
                pkg = {"name": app_id, "repo": "flathub", "version": version, "installed": False, "desc": f"{name} - {desc}"}
                self.add_item_to_list(pkg)

    def add_item_to_list(self, pkg):
        display_text = f"{pkg['name']} (v{pkg['version']}) - {pkg['repo']}"
        if pkg['installed']:
            display_text += " [INSTALLED]"
        display_text += f"\n{pkg['desc']}"
        
        item = QListWidgetItem(display_text)
        item.setData(Qt.ItemDataRole.UserRole, pkg['name'])
        
        # Visually differentiate installed packages
        if pkg['installed']:
            item.setForeground(Qt.GlobalColor.white)
            font = item.font()
            font.setBold(True)
            item.setFont(font)
        else:
            item.setForeground(Qt.GlobalColor.lightGray)
            
        self.result_list.addItem(item)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = AppStore()
    window.show()
    sys.exit(app.exec())
