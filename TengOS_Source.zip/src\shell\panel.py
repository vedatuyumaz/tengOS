import sys
from PySide6.QtWidgets import QWidget, QHBoxLayout, QLabel, QPushButton, QSpacerItem, QSizePolicy
from PySide6.QtCore import Qt, QTimer, QDateTime
from PySide6.QtGui import QIcon, QFont

class TopPanel(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        
    def initUI(self):
        # Frameless and translucent window
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        
        # Dimensions and Position (Assuming 1920x1080 for prototype, will be dynamic in production)
        self.setGeometry(0, 0, 1920, 40)
        self.setObjectName("tengos-shell-panel")
        
        # Styling
        self.setStyleSheet("""
            QWidget#tengos-shell-panel {
                background-color: rgba(20, 20, 20, 0.85);
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            }
            QPushButton {
                background: transparent;
                color: #ffffff;
                border: none;
                padding: 5px 15px;
                font-family: 'Inter', 'Segoe UI', sans-serif;
                font-size: 14px;
                font-weight: 500;
                border-radius: 6px;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.1);
            }
            QLabel {
                color: #ffffff;
                font-family: 'Inter', 'Segoe UI', sans-serif;
                font-size: 14px;
                padding: 0 10px;
            }
        """)

        layout = QHBoxLayout()
        layout.setContentsMargins(10, 0, 10, 0)
        layout.setSpacing(5)

        # Launcher Button (Start Menu)
        self.btn_launcher = QPushButton("Teng OS")
        font = QFont()
        font.setBold(True)
        self.btn_launcher.setFont(font)
        layout.addWidget(self.btn_launcher)

        # Workspaces (Mockup for now)
        self.btn_ws1 = QPushButton("1")
        self.btn_ws2 = QPushButton("2")
        layout.addWidget(self.btn_ws1)
        layout.addWidget(self.btn_ws2)

        # Spacer to push everything else to the right
        spacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        layout.addItem(spacer)

        # System Tray / Indicators (Mockup)
        self.btn_network = QPushButton("Wi-Fi")
        self.btn_battery = QPushButton("100%")
        layout.addWidget(self.btn_network)
        layout.addWidget(self.btn_battery)

        # Clock
        self.lbl_clock = QLabel()
        layout.addWidget(self.lbl_clock)
        self.update_time()

        # Timer for Clock
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)

        self.setLayout(layout)

    def update_time(self):
        current_time = QDateTime.currentDateTime().toString("ddd dd MMM hh:mm")
        self.lbl_clock.setText(current_time)
