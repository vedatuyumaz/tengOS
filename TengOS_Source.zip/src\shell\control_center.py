import sys
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QSlider, QFrame
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

class ControlCenter(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        
    def initUI(self):
        # Frameless, translucent overlay window
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.Tool)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        
        # Geometry: Docked to the top right
        width = 340
        height = 420
        x = 1920 - width - 20
        y = 50
        self.setGeometry(x, y, width, height)
        self.setObjectName("tengos-control-center")

        # Classy, minimalist styling (Grayscale & whitish-blue)
        self.setStyleSheet("""
            QWidget#tengos-control-center {
                background-color: rgba(22, 22, 22, 0.95);
                border-radius: 14px;
                border: 1px solid rgba(255, 255, 255, 0.1);
            }
            QLabel {
                color: #ffffff;
                font-family: 'Inter', sans-serif;
            }
            QLabel.section-title {
                font-size: 13px;
                font-weight: bold;
                color: rgba(255, 255, 255, 0.5);
                text-transform: uppercase;
                margin-top: 10px;
            }
            QPushButton.toggle-btn {
                background-color: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 8px;
                padding: 12px;
                color: #ffffff;
                text-align: left;
                font-size: 14px;
            }
            QPushButton.toggle-btn:hover {
                background-color: rgba(255, 255, 255, 0.1);
            }
            QPushButton.toggle-btn:checked {
                background-color: rgba(220, 230, 242, 0.2);
                border: 1px solid rgba(220, 230, 242, 0.6);
                color: #ffffff;
            }
            QSlider::groove:horizontal {
                border-radius: 4px;
                height: 8px;
                background: rgba(255, 255, 255, 0.1);
            }
            QSlider::handle:horizontal {
                background: #ffffff;
                width: 16px;
                margin: -4px 0;
                border-radius: 8px;
            }
            QSlider::sub-page:horizontal {
                background: rgba(220, 230, 242, 0.6);
                border-radius: 4px;
            }
            QFrame.separator {
                background-color: rgba(255, 255, 255, 0.05);
                max-height: 1px;
                margin: 10px 0;
            }
        """)

        layout = QVBoxLayout()
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(8)

        # Header
        header = QLabel("Control Center")
        header.setStyleSheet("font-size: 16px; font-weight: bold;")
        layout.addWidget(header)
        
        sep1 = QFrame()
        sep1.setProperty("class", "separator")
        layout.addWidget(sep1)

        # Connectivity Section
        lbl_conn = QLabel("Connectivity")
        lbl_conn.setProperty("class", "section-title")
        layout.addWidget(lbl_conn)

        self.btn_wifi = QPushButton("Wi-Fi: Connected")
        self.btn_wifi.setProperty("class", "toggle-btn")
        self.btn_wifi.setCheckable(True)
        self.btn_wifi.setChecked(True)
        layout.addWidget(self.btn_wifi)

        self.btn_bt = QPushButton("Bluetooth: Off")
        self.btn_bt.setProperty("class", "toggle-btn")
        self.btn_bt.setCheckable(True)
        layout.addWidget(self.btn_bt)

        # Display Section
        lbl_disp = QLabel("Display & Audio")
        lbl_disp.setProperty("class", "section-title")
        layout.addWidget(lbl_disp)

        # Brightness
        row_bright = QHBoxLayout()
        row_bright.addWidget(QLabel("Brightness"))
        self.slider_bright = QSlider(Qt.Orientation.Horizontal)
        self.slider_bright.setValue(80)
        row_bright.addWidget(self.slider_bright)
        layout.addLayout(row_bright)

        # Volume
        row_vol = QHBoxLayout()
        row_vol.addWidget(QLabel("Volume"))
        self.slider_vol = QSlider(Qt.Orientation.Horizontal)
        self.slider_vol.setValue(50)
        row_vol.addWidget(self.slider_vol)
        layout.addLayout(row_vol)

        sep2 = QFrame()
        sep2.setProperty("class", "separator")
        layout.addWidget(sep2)

        # Theme Section
        lbl_theme = QLabel("Appearance")
        lbl_theme.setProperty("class", "section-title")
        layout.addWidget(lbl_theme)

        row_theme = QHBoxLayout()
        self.btn_dark = QPushButton("Dark Mode")
        self.btn_dark.setProperty("class", "toggle-btn")
        self.btn_dark.setCheckable(True)
        self.btn_dark.setChecked(True)
        
        self.btn_light = QPushButton("Light Mode")
        self.btn_light.setProperty("class", "toggle-btn")
        self.btn_light.setCheckable(True)
        
        row_theme.addWidget(self.btn_dark)
        row_theme.addWidget(self.btn_light)
        layout.addLayout(row_theme)

        layout.addStretch()
        self.setLayout(layout)

    def toggle_visibility(self):
        if self.isVisible():
            self.hide()
        else:
            self.show()
